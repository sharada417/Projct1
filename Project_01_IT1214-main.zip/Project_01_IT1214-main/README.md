# Project_01_IT1214
This repo contains my( 2020/ICT/19 ) Project_01 of the subject IT1214.
